<template>
  <div class="xl-center-sidebar"></div>
</template>

<script>
export default {
  data() {
    return {};
  },

  components: {},

  computed: {},

  methods: {},
};
</script>
<style lang='scss' scoped>
.xl-center-sidebar {
  width: 300px;
  height: 100%;
  background-color: $FolderBg;
}
</style>